<?php

require_once("./function.php");
// var_dump($_SERVER["REQUEST_URI"]);die;
$uri = $_SERVER["REQUEST_URI"];
$decoupe = explode("/", $uri );

// var_dump($decoupe[1]);die;
if ($decoupe[1] === ""  ) {
  header('Location: home.php');
} else {
    $decoupe[1]();
};
