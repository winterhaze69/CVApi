<?php
  session_start();
  function getAllUser() {
    $request = '
    SELECT *
    FROM  Users
    ';
    $connec = new PDO('mysql:dbname=CV', 'root', '0000');
    $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $request = $connec->prepare($request);
    $request->execute();
    return $request->fetchAll();
  }
  $users = getAllUser();
  $n = count($users);
  $a = 0;

    foreach ($users as $user) {
      $name = $_POST["name"];
      $password = $_POST["password"];
        if (in_array($name, $user) && in_array($password,$user)) {
            return require_once('./page1.php');
        }
      };
      return require_once('./noregister.php');

  // foreach ($users as $user) {
  //
  // $name = $_POST["name"];
  // $password = $_POST["password"];
  //
  //   if (in_array($name, $user) && in_array($password,$user)) {
  //       return require_once('./page1.php');
  //   }  else {
  //       return require_once('./home.php');
  //     }
  // }


  // foreach ($users as $user) {
  //   $name = $_POST["name"];
  //   $password = $_POST["password"];
  //   if ($user["name"] === $name && $user["password"] === $password){
  //       return require_once('./page1.php');
  //   } else {
  //       echo " va te faire enculer bataaaard !";
  //   }
  // }


 ?>
