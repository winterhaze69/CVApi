
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./style/style2.css">
    <title></title>
  </head>
  <body>
    <!-- <form class="all" action="./function.php" method="post"> -->

      <div class="title">
        <h1>Entrez les informations</h1>
      </div>


        <div class="first">
            <div class="info">
              <form class="all" action="/insertInfo" method="post">
                  <label for="info">Informations:</label>
                    <input type="text" name="name" value="" placeholder="Nom">
                    <input type="number" name="age" value="" placeholder="Age">
                    <input type="text" name="adress" value="" placeholder="Adresse">
                    <input type="number" name="tel" value="" placeholder="Téléphone">
                    <input type="email" name="mail" value="" placeholder="E-mail">
                    <input type="submit" name="" value="Validez!">
                </form>
            </div>

              <div class="formation">
                <form class="all" action="./insertFormation" method="post">
                  <label for="formation">Formations:</label>
                  <input type="text" name="educationname[]" value="" placeholder="Titre formation">De
                  <input type="number" name="educationStart[]" value="" placeholder="Année">à
                  <input type="number" name="educationEnd[]" value="" placeholder="Année">
                  <input type="text" name="educationContent[]" value=""placeholder="Texte">
                  <input type="submit" name="" value="Validez!">
                </form>
              </div>
        </div>
        <div class="second">
                <div class="competences">
                  <form class="all" action="./insertOneComp" method="post">
                    <label for="competences">Compétences:</label>
                    <input type="text" name="insertOneComp" value="" placeholder="name">
                    <input type="submit" name="" value="Validez!">
                  </form>
                </div>

                <div class="experience">
                    <form class="all" action="./insertExp" method="post">
                      <label for="experience">Expériences:</label>
                      <input type="text" name="experienceName[]" value="" placeholder="Titre poste">De
                      <input type="number" name="experienceStart[]" value="" placeholder="Année">à
                      <input type="number" name="experienceEnd[]" value="" placeholder="Année">
                      <input type="text" name="experienceContent[]" value=""placeholder="Texte">
                      <input type="submit" name="" value="Validez!">
                    </form>
                </div>
        </div>

        <div class="third">
            <div class="interest">
              <form class="all" action="./function.php" method="post">
                <label for="interest">Centre d'interêts:</label>
                <input type="text" name="hobbyname[]" value="" placeholder="Interêts">
                <input type="submit" name="" value="Validez!">
              </form>
            </div>

            <div class="interest">
              <form class="all" action="./function.php" method="post">
                <label for="langues">Langues:</label>
                <input type="text" name="languagename[]" value="" placeholder="Langue">
                <input type="submit" name="" value="Validez!">
              </form>
            </div>
        </div>

          <input type="submit" name="" value="Validez!">

  <!--   </form> -->
  </body>
</html>



experience();
