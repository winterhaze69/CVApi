<?php

// $age = ['marc', 43];
//
// $type = gettype($age);
//
// if (is_int($age[1])) {
//   echo "ceci est un nombre";
// } else {
//   echo "non";
// }

//une session est un tableau dans lequel on stock une valeur
session_start();

// $_SESSION['name'] = "Jean-Michel";
// var_dump($_POST);die;


function getAllCV() {
  $request = '
  SELECT CVs.name, Skills.name as skills, Educations.name as education, Educations.content,
  Educations.startdate, Educations.enddate,
  Hobbies.name as Hobbies, Experiences.name as experience, Experiences.content as experiencecontent,
  Experiences.startdate as experiencestartdate, Experiences.enddate as experienceenddate, Users.name,
  Users.tel, Users.mail, Users.age, Users.adress, Languages.name as language
  FROM  CVs
  INNER JOIN Educations ON Educations.id=CVs.education_id
  INNER JOIN Experiences ON Experiences.id=CVs.experience_id
  INNER JOIN Hobbies ON Hobbies.id=CVs.hobby_id
  INNER JOIN Skills ON Skills.id=CVs.skill_id
  INNER JOIN Users ON Users.id=CVs.user_id
  INNER JOIN Languages ON Languages.id=CVs.language_id
  ';
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}

// function getAllCVs() {
//   $request = '
//   SELECT CVs.name, GROUP_CONCAT(Educations.content) as education,
//   GROUP_CONCAT(Languages.name) as languages,
//   FROM  CVs
//   INNER JOIN CV_Education ON CVs.id = CV_Education.CV_id
//   INNER JOIN Educations ON Educations.id=CV_Education.Education_id
//   INNER JOIN CV_Language ON CVs.id = CV_Language.CV_id
//   INNER JOIN Languages ON Languages.id=CV_Language.Language_id
//   GROUP BY CVs.id;
//   ';
//   $connec = new PDO('mysql:dbname=CV', 'root', '0000');
//   $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//   $request = $connec->prepare($request);
//   $request->execute();
//   return $request->fetchAll();
// }



// Skills

function getAllSkills() {
  $request = '
  SELECT *
  FROM  Skills
  ';
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}

//Inserts

function insertInfo() {
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare('INSERT INTO Skills (name) VALUES (:name)');
  $request->execute([
    ":name" => $name,
      ":age" => $age,
        ":tel" => $tel,
          ":mail" => $mail,
            ":adress" => $adress,


  ]);
}
function insertFormation() {
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare('INSERT INTO Skills (name) VALUES (:name)');
  $request->execute([
    ":educationname[]" => $edName,
":educationStart[]" => $edStart,
":educationEnd[]" => $edEnd,
":educationContent[]" => $edCont
  ]);
}
function insertOneComp() {
  var_dump($_POST);die;
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare('INSERT INTO Skills (name) VALUES (:name)');
  $request->execute([
    ":insertOneComp" => $insertOneComp
  ]);
}
function insertExp() {
  var_dump($_POST);die;
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare('INSERT INTO Skills (name) VALUES (:name)');
  $request->execute([
    ":experienceName[]" => $xpName,
":experienceStart[]" => $xpStart,
":experienceEnd[]" => $xpEnd,
":experienceContent[]" => $xpContent
  ]);
}
// A reprendre ici
function deleteOneProduct() {
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare('DELETE FROM Skills WHERE id = :id');
  $request->execute([
    ":id" => $product_id,
  ]);
}





// Education

function getAllEducation() {
  $request = '
  SELECT *
  FROM  Educations
  ';
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}



// Hobbies

function getAllHobbies() {
  $request = '
  SELECT *
  FROM  Hobbies
  ';
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}





// Experiences

function getAllExperiences() {
  $request = '
  SELECT *
  FROM  Experiences
  ';
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}




// User

function getAllUser() {
  $request = '
  SELECT *
  FROM  Users
  ';
  $connec = new PDO('mysql:dbname=CV', 'root', '0000');
  $connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $request = $connec->prepare($request);
  $request->execute();
  return $request->fetchAll();
}
