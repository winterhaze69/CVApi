

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./style/style.css">
    <title>CV</title>
  </head>
  <body>
    <div>
      <form method="post" action="authentification.php">
        <label>Username</label>
        <input type="text" name="name">
        <label>Password</label>
        <input type="text" name="password">
        <input type="submit" value="register !">
      </form>
    </div>
    <div class="title">
      <h1>Création de</h1>
      <h1>CV</h1>
      <h1>en ligne</h1>
    </div>

    <div class="connection">
      <form class="" action="./page.php" method="post">
        <label for="Nom">Nom d'utilisateur :</label>
        <input type="text" name="name" value="" maxlength="25">
        <label for="password">Mot de passe :</label>
        <input type="text" name="password" value="" maxlength="25">
        <input type="submit" name="" value="Ok!">
      </form>
    </div>
  </body>
</html>
