<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./style/style2.css">
    <title></title>
  </head>
<body>
  <p>OOOOPS !</p>
  <img src="./img/oops.gif" alt="oops"/>
  <div class="message">Désolé mais votre identifiant ou mot de passe n'existe pas</div>
  <button><a href="./home.php">M'identifier</a></button>
</body>
