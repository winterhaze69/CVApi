
<?php 
  include_once("./templates/header.php")
?>
    <ul>
      <li><a href="./page1.php">New CV</a></li>
      <li><a href="./CRUDCV.php">Modifier un CV</a></li>
    </ul>

<?php 
  include_once("./templates/footer.php")
?>